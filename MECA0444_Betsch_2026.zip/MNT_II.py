import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
import os
from partie1_1 import *  
from opti_angle import *


x1 = L1_II              # palier gauche
x2 = L1_II + L2_II      # engrenage
x3 = L_II               # palier droit

x = np.linspace(0, L_II, 2000)
TOL = 1e-6


def plot2(y, title, ylabel):
    os.makedirs("figures_II", exist_ok=True)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(x, y, linewidth=2)

    ax.axvline(x1, linestyle="--", color="orange", linewidth=1.5)
    ax.axvline(x2, linestyle="--", color="orange", linewidth=1.5)

    ax.grid(True, linestyle="--", alpha=0.7)

    ax.set_xlabel("x [mm]", fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=13)

    ax.set_xlim(0, L_II)
    ax.set_xticks(np.arange(0, L_II + 1, 25))

    fig.tight_layout()

    filepath = os.path.join("figures_II", title + ".png")
    plt.grid(True , **grid_style)
    fig.savefig(filepath, dpi=600)
    plt.close(fig)




Ft_R2, Fr_R2, Fa_R2 = force_engrenage(P, dr_2, N2[index], 20, best_beta2)


#Force non signée

Ft = float(Ft_R2)
Fr = float(Fr_R2)
Fa = float(Fa_R2) 
Mg = float(M*g)

# =========================
# Forces SIGNÉES (Arbre II)
# =========================
Fy0 = -Mg
C_Mg = Lg * Mg

theta = np.radians(60) 

Fx2 = +Fa      # +x_II
Fy2 = -Fr*np.cos(theta) - Ft * np.sin(theta) 
Fz2 = +Fr * np.sin(theta) - Ft * np.cos(theta)   



# Couple concentré autour de z dû à l'effort axial appliqué à un rayon dr/2
M0z = +Fa * (dr_2 / 2.0)  # [Nmm]

# =========================
# Réactions d'appuis 
# =========================
R1x, R1y, R2y, R1z, R2z = sp.symbols("R1x R1y R2y R1z R2z")
eqs = []

# Somme des forces = 0
eqs.append(sp.Eq(R1x + Fx2, 0))                 #selon x
eqs.append(sp.Eq(R1y + R2y + Fy0 + Fy2, 0))     #selon y
eqs.append(sp.Eq(R1z + R2z + Fz2, 0))           #selon z

# Moments au point x=0
# Autour de z 
eqs.append(sp.Eq(R1y * x1 + R2y * x3 + Fy2 * x2 + M0z, C_Mg))

# Autour de y 
eqs.append(sp.Eq(R1z * x1 + R2z * x3 + Fz2 * x2, 0))

sol = sp.solve(eqs, [R1x, R1y, R2y, R1z, R2z], dict=True)
if not sol:
    raise RuntimeError("Pas de solution pour les réactions de l'arbre II.")
sol = sol[0]

R1x_v = float(sol[R1x])
R1y_v = float(sol[R1y])
R2y_v = float(sol[R2y])
R1z_v = float(sol[R1z])
R2z_v = float(sol[R2z])



# =========================
# Check équilibre global
# =========================
sumFx = R1x_v + Fx2
sumFy = R1y_v + R2y_v + Fy0 + Fy2
sumFz = R1z_v + R2z_v + Fz2



# =========================
# Diagrammes internes : N, Ty, Tz
# (somme des actions à gauche)
# =========================
N = np.zeros_like(x)
Ty = np.zeros_like(x)
Tz = np.zeros_like(x)



mask1 = (x >= 0) & (x < x1)
mask2 = (x >= x1) & (x < x2)
mask3 = (x >= x2) & (x <= L_II)


# N(x) selon ton découpage : 0 puis -R1x puis -R1x - Fa
N[mask1] = 0.0
N[mask2] = -R1x_v
N[mask3] = -R1x_v - Fa

# Ty(x)
Ty[mask1] = Fy0
Ty[mask2] = Fy0 + R1y_v
Ty[mask3] = Fy0 + R1y_v + Fy2

# Tz(x)
Tz[mask1] = 0.0
Tz[mask2] = R1z_v
Tz[mask3] = R1z_v + Fz2



# =========================
# Moments fléchissants : My, Mz (N·mm)
# =========================
My = np.zeros_like(x)  # autour de y : forces en z
Mz = np.zeros_like(x)  # autour de z : forces en y + couple M0z


# My(x) 
My[mask1] = 0.0
My[mask2] = -(R1z_v * (x[mask2] - x1))
My[mask3] = -(R1z_v * (x[mask3] - x1) + Fz2 * (x[mask3] - x2))

# Mz(x) 
Mz[mask1] = C_Mg +  Fy0 * x[mask1]
Mz[mask2] = C_Mg +  Fy0 * x[mask2] + R1y_v * (x[mask2] - x1)
Mz[mask3] = C_Mg +  Fy0 * x[mask3] + R1y_v * (x[mask3] - x1) + Fy2 * (x[mask3] - x2) - M0z



Mf = np.sqrt(My**2 + Mz**2)

# =========================
# Torsion Mt(x) : Cm sur [0, x2), puis 0
# =========================
Cm_Nmm = Ft * (dr_2 / 2.0)  # [N·mm]
M_t = np.zeros_like(x)
M_t[(x >= 0) & (x < x2)] = Cm_Nmm
M_t[(x >= x2) & (x <= L_II)] = 0.0


# =========================
# Plots
# =========================
plot2(N, r"Arbre II — Effort normal $N(x)$",r"$N$ [N]")
plot2(Ty, r"Arbre II — Effort tranchant $T_y(x)$",r"$T_y$ [N]")
plot2(Tz, r"Arbre II — Effort tranchant $T_z(x)$",r"$T_z$ [N]")
plot2(My, r"Arbre II — Moment fléchissant $M_y(x)$",r"$M_y$ [Nmm]")
plot2(Mz, r"Arbre II — Moment fléchissant $M_z(x)$",r"$M_z$ [Nmm]")
plot2(Mf, r"Arbre II — Moment résultant $M_f(x)$",r"$M_f$ [Nmm]")
plot2(M_t, r"Arbre II — Torsion $M_t(x)$",r"$M_t$ [Nmm]")
Mi = np.sqrt(Mf**2 + M_t**2)
plot2(Mi, r"Arbre II — Moment idéal $M_i(x)$",r"$M_i$ [Nmm]")












#Print Vérif



#print("\n=== Reactions Arbre II ===")
#print(f"R1x = {R1x_v:.2f} N")
#print(f"R1y = {R1y_v:.2f} N, R2y = {R2y_v:.2f} N")
#print(f"R1z = {R1z_v:.2f} N, R2z = {R2z_v:.2f} N")
#
#print("\n--- Check equilibre global Arbre II ---")
#print(f"SumFx = {sumFx:.6e}")
#print(f"SumFy = {sumFy:.6e}")
#print(f"SumFz = {sumFz:.6e}")
#
#if max(abs(sumFx), abs(sumFy), abs(sumFz)) > TOL:
#    print("ATTENTION : equilibre global NON respecté (vérifier les signes Fy0/Fy2/Fz2/Fx2).")
#else:
#    print("Equilibre global OK.")
#
#
#print("\n--- Fermeture tranchants (x = L-) ---")
#print(f"Ty(L-) = {Ty[-1]:.2f} ; -R2y = {-R2y_v:.2f} ; diff = {Ty[-1] + R2y_v:.2e}")
#print(f"Tz(L-) = {Tz[-1]:.2f} ; -R2z = {-R2z_v:.2f} ; diff = {Tz[-1] + R2z_v:.2e}")
#
#print("\n--- Check fermeture moments ---")
#print(f"My(L-) = {My[-1]:.2f} Nmm")
#print(f"Mz(L-) = {Mz[-1]:.2f} Nmm")
#
#print("\n--- Check couple ---")
#print(f"Ft * (dr_2 / 2.0) = {Cm_Nmm/1000:.2f}Nm")
#w2 = N2[index]*2*np.pi/60
#print(f"P/W2 = {P*1000/w2:.2f} Nm")