from partie1_1 import *
import numpy as np
from scipy.optimize import bisect

# =======================
# Données géométriques
# =======================

L0T_m = L0T/1000
L1T_m = L1T/1000
L2T_m = L2T/1000
L3T_m = L3T/1000
x4_m = L_T/1000

dt_m = dt * 1e-3

It = np.pi * dt_m**4 / 64

# =======================
# Contribution turbine
# =======================

a_ii_t = (L3T_m**2) * (2*L1T_m + L2T_m + L3T_m) / (3 * E * It)
w_t = np.sqrt(1/(m * a_ii_t))

# =======================
# Contribution pignon
# =======================
a = L1T_m
b = L1T_m + L2T_m
L = a + b

a_ii_p = (a**2 * b**2) / (3 * E * It * L)

w_p = np.sqrt(1/(m_pinion_T * a_ii_p))

# =======================
# Masse linéique arbre
# =======================

A = np.pi * dt_m**2 / 4
m_lin = rho * A



# ===============================
# 2) Contribution du poids propre
# ===============================


f1  = lambda x: np.sinh(x) + np.sin(x)
f2  = lambda x: np.sinh(x) - np.sin(x)
f3  = lambda x: np.cosh(x) + np.cos(x)
f4  = lambda x: np.cosh(x) - np.cos(x)

f1p  = lambda x: np.cosh(x) + np.cos(x)
f2p  = lambda x: np.cosh(x) - np.cos(x)
f3p  = lambda x: np.sinh(x) - np.sin(x)
f4p  = lambda x: np.sinh(x) + np.sin(x)

f1pp = lambda x: np.sinh(x) - np.sin(x)  
f2pp = lambda x: np.sinh(x) + np.sin(x)  
f3pp = lambda x: np.cosh(x) - np.cos(x)
f4pp = lambda x: np.cosh(x) + np.cos(x)



x0_m = L0T_m
x1_m = L0T_m + L1T_m
x2_m = L0T_m + 2*L1T_m
x3_m = L0T_m + 2*L1T_m + L2T_m
x4_m = L_T/1000
x_mid = L_T/2.0


def det(w):
    a = (m_lin * w**2 / (E * It))**(1/4)
    A = np.array([
        [f1(a*x0_m), f2(a*x0_m), f3(a*x0_m), f4(a*x0_m)], 
        [f1(a*x3_m), f2(a*x3_m), f3(a*x3_m), f4(a*x3_m)], 
        [f1pp(0), f2pp(0), f3pp(0), f4pp(0)], 
        [f1pp(a*x4_m), f2pp(a*x4_m), f3pp(a*x4_m), f4pp(a*x4_m)], 
    ])
    return np.linalg.det(A)

w_guess = np.linspace(0.1, 50000, 50000)
det_array = np.array([det(w) for w in w_guess])



sign_changes = []

for i in range(1, len(det_array)):
    if np.sign(det_array[i]) != np.sign(det_array[i-1]):
        sign_changes.append(i)
 




roots = []

for i in sign_changes:
    w_root = bisect(det, w_guess[i-1], w_guess[i]) #trouve la racine dans l'intervale, on le fait la ou il y a un changement de signe
    roots.append(w_root)



w_A = roots[0]




w_rot = 2*np.pi*Nt/60.0



w_c = np.sqrt(1/(1/w_t**2 + 1/w_p**2 + 1/w_A**2))



N_t = w_t * 60/(2*np.pi)
N_p = w_p * 60/(2*np.pi)
N_A = w_A * 60/(2*np.pi)
N_c = w_c * 60/(2*np.pi)

#print("===== Verification dynamique arbre T =====")
#
#print(f"N_turbine = {N_t:.2f} tr/min")
#print(f"N_pignon  = {N_p:.2f} tr/min")
#print(f"N_arbre   = {N_A:.2f} tr/min")
#print("\n")
#print(f"N_crit = {N_c:.2f} tr/min")
#print(f"N_rot  = {Nt:.2f} tr/min")
#print("\n")
#print(f"w arbre = {w_A:.2f} rad/s")
#print("det(w) =", det(w_A))
