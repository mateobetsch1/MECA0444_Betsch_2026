from partie1_1 import *

alpha = 20

beta_range = np.linspace(5, 35, 200)

best_err = np.inf
best_beta1 = np.nan
best_beta2 = np.nan

for beta1 in beta_range:
    for beta2 in beta_range:

        Ft1, Fr1, Fa1 = force_engrenage(P, d_pinion_T, Nt, alpha, beta1)
        Ft2, Fr2, Fa2 = force_engrenage(P, d_pinion_1[index], N1[index], alpha, beta2)

        Fa_total = abs(Fa1 - Fa2)

        if abs(Fa_total) < best_err:
            best_err = abs(Fa_total)
            best_beta1 = beta1
            best_beta2 = beta2

#print("\n=== Optimisation angles helice ===")
#print(f"beta1 optimal : {best_beta1:.2f}")
#print(f"beta2 optimal : {best_beta2:.2f}")
#print(f"Resultante axiale : {best_err:.2f} N")


dp_T = float(d_pinion_T)
dr_1 = float(d_wheel_1[index])   # roue 1 sur arbre I
dp_1 = float(d_pinion_1[index])  # pignon 1 sur arbre I
dr_2 = float(d_wheel_2[index])

# --- ÉTAGE 1 (T -> I) ---
# Calcul sur le pignon (Arbre T)
Ft_T, Fr_T, Fa_T = force_engrenage(P, dp_T, Nt, 20, best_beta1)

# Calcul sur la roue (Arbre I) - La vitesse est N1
Ft_R1, Fr_R1, Fa_R1 = force_engrenage(P, dr_1, N1[index], 20, best_beta1)

# --- ÉTAGE 2 (I -> II) ---
# Calcul sur le pignon (Arbre I)
Ft_P1, Fr_P1, Fa_P1 = force_engrenage(P, dp_1, N1[index], 20, best_beta2)

# Calcul sur la roue (Arbre II) - La vitesse est N2
Ft_R2, Fr_R2, Fa_R2 = force_engrenage(P, dr_2, N2[index], 20, best_beta2)


#print(f"=== VERIFICATION ACTION-REACTION ETAGE 1 ===")
#print(f"Pignon Turbine : Ft={Ft_T:.2f} N, Fr={Fr_T:.2f} N, Fa={Fa_T:.2f} N")
#print(f"Roue 1 (Arbre I): Ft={Ft_R1:.2f} N, Fr={Fr_R1:.2f} N, Fa={Fa_R1:.2f} N")
#
#print(f"\n=== VERIFICATION ACTION-REACTION ETAGE 2 ===")
#print(f"Pignon 1 (Arbre I): Ft={Ft_P1:.2f} N, Fr={Fr_P1:.2f} N, Fa={Fa_P1:.2f} N")
#print(f"Roue 2 (Arbre II): Ft={Ft_R2:.2f} N, Fr={Fr_R2:.2f} N, Fa={Fa_R2:.2f} N")
