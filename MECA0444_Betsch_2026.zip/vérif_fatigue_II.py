from partie1_1 import * 


L1II_m = L1_II/1000  # m
L2II_m = L2_II/1000  # m
L3II_m = L3_II/1000  # m

L_II_m = L1II_m + L2II_m + L3II_m # m 

Lg_m = Lg/1000

d_II_m = d2[index]/1000
I_II = np.pi * (d_II_m)**4 / 64

term_g1 = (L1II_m ** 2)* (L1II_m + L2II_m + L3II_m) / (3 * E * I_II)
term_g2 = ( Lg_m * (L1II_m ** 2) / (2 * E * I_II) + Lg_m * L1II_m * (L2II_m + L3II_m ) / (3 * E * I_II))


ag_II = abs( term_g1 - term_g2 ) 
ae_II = (L2II_m**2) * (L3II_m**2) / (3 * E * I_II * (L2II_m + L3II_m))

w_g_II = np.sqrt(1 / (M * ag_II))
w_e_II = np.sqrt(1 / (m_wheel_2[index] * ae_II))
w_a_II = (np.pi**2 / (L2II_m + L3II_m)**2) * np.sqrt(E * I_II / (rho * np.pi * d_II_m**2 / 4))



w_c_II = 1 / np.sqrt((1 / w_g_II**2) + (1 / w_e_II**2) + (1 / w_a_II**2))


Ncrit_II = w_c_II * 60 / (2 * np.pi)

#print("===== Verification dynamique arbre II =====")
#
#print(f"a masse Mg = {ag_II:.6e} m/N")
#print(f"a engrenage = {ae_II:.6e} m/N")
#
#print("\n")
#
#print(f"w_g = {w_g_II:.3f} rad/s")
#print(f"w_e = {w_e_II:.3f} rad/s")
#print(f"w_A = {w_a_II:.3f} rad/s")
#print(f"w_c = {w_c_II:.3f} rad/s")
#
#print("\n")
#
#print(f"N_crit = {Ncrit_II:.1f} rpm")
#print(f"N_rot  = {N2[index]:.1f} rpm")