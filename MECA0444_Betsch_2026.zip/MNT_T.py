import sympy as sp
import numpy as np
import matplotlib.pyplot as plt
import os
from partie1_1 import *
from opti_angle import * 


x0 = L0T
x1 = L0T + L1T
x2 = L0T + 2*L1T
x3 = L0T + 2*L1T + L2T
x4 = L_T
x_mid = L_T/2.0


mg = float(m * g)  # N


FtT, FrT, FaT, = Ft_T, Fr_T, Fa_T



def plotT(xvec, y, title, ylabel, folder="figures_T"):
    os.makedirs(folder, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(xvec, y, linewidth=2)

    for xv in [x0, x1, x2, x3, x4]:
        ax.axvline(xv, linestyle="--", color="orange", linewidth=1.2)

    ax.grid(True, linestyle="--", alpha=0.7)
    ax.set_xlabel("x [mm]")
    ax.set_ylabel(ylabel)
    ax.set_title(title)

    ax.set_xlim(0, L_T)
    ax.set_xticks(np.arange(0, L_T + 50, 100))

    fig.tight_layout()
    fig.savefig(os.path.join(folder, title + ".png"), dpi=600)
    plt.close(fig)



x = sp.Symbol("x", real=True)
R2y_sym, R2z_sym = sp.symbols("R2y R2z", real=True)

R1y_expr = (-FrT*(L1T+L2T) - FaT*(dp_T/2) - R2y_sym*L2T - mg*L3T ) / (2*L1T + L2T)
R3y_expr = mg - FrT - R2y_sym - R1y_expr

R1z_expr = (FtT*(L1T+L2T) - R2z_sym*L2T) / (2*L1T + L2T)
R3z_expr = FtT - R2z_sym - R1z_expr

# Mfz segments: [x0,x1], [x1,x2], [x2,x_mid], [x_mid,x3], [x3,x4]
Mfz_1 = R1y_expr*(x - x0)
Mfz_2 = Mfz_1 + FrT*(x - x1) + FaT*(dp_T/2)
Mfz_3 = Mfz_2 + R2y_sym*(x - x2)
Mfz_4 = Mfz_3
Mfz_5 = Mfz_4 + R3y_expr*(x - x3)

Iy = (
    sp.integrate(sp.expand(Mfz_1*sp.diff(Mfz_1, R2y_sym)), (x, x0, x1)) +
    sp.integrate(sp.expand(Mfz_2*sp.diff(Mfz_2, R2y_sym)), (x, x1, x2)) +
    sp.integrate(sp.expand(Mfz_3*sp.diff(Mfz_3, R2y_sym)), (x, x2, x_mid)) +
    sp.integrate(sp.expand(Mfz_4*sp.diff(Mfz_4, R2y_sym)), (x, x_mid, x3)) +
    sp.integrate(sp.expand(Mfz_5*sp.diff(Mfz_5, R2y_sym)), (x, x3, x4))
)

# Mfy segments: [x0,x1], [x1,x2], [x2,x3], [x3,x4]
Mfy_1 = R1z_expr*(x - x0)
Mfy_2 = Mfy_1 - FtT*(x - x1)
Mfy_3 = Mfy_2 + R2z_sym*(x - x2)
Mfy_4 = Mfy_3 + R3z_expr*(x - x3)

Iz = (
    sp.integrate(sp.expand(Mfy_1*sp.diff(Mfy_1, R2z_sym)), (x, x0, x1)) +
    sp.integrate(sp.expand(Mfy_2*sp.diff(Mfy_2, R2z_sym)), (x, x1, x2)) +
    sp.integrate(sp.expand(Mfy_3*sp.diff(Mfy_3, R2z_sym)), (x, x2, x3)) +
    sp.integrate(sp.expand(Mfy_4*sp.diff(Mfy_4, R2z_sym)), (x, x3, x4))
)

# Résolution (2 équations indépendantes)
sol_R2y = sp.solve(sp.Eq(sp.factor(Iy), 0), R2y_sym)
sol_R2z = sp.solve(sp.Eq(sp.factor(Iz), 0), R2z_sym)
if not sol_R2y or not sol_R2z:
    raise RuntimeError("Pas de solution Castigliano (vérifie segments/charges).")

R2y_v = float(sp.N(sol_R2y[0]))
R2z_v = float(sp.N(sol_R2z[0]))

R1y_v = float(sp.N(R1y_expr.subs(R2y_sym, R2y_v)))
R3y_v = float(sp.N(R3y_expr.subs(R2y_sym, R2y_v)))
R1z_v = float(sp.N(R1z_expr.subs(R2z_sym, R2z_v)))
R3z_v = float(sp.N(R3z_expr.subs(R2z_sym, R2z_v)))

R3x = FaT - F2


xx = np.linspace(0.0, L_T, 5000)

mask0  = (xx >= 0.0)   & (xx < x0)         
mask1  = (xx >= x0)    & (xx < x1)
mask2  = (xx >= x1)    & (xx < x2)
mask3a = (xx >= x2)    & (xx < x_mid)  #ici j'ai deux mask pour la moitier car j'avais fait une erreur mais j'ai laissé (if it works, it works we don't touch it ;) )
mask3b = (xx >= x_mid) & (xx < x3)
mask4  = (xx >= x3)    & (xx <= x4)

#Effort axial 
N = np.zeros_like(xx)
N[mask0]  = 0
N[mask1]  = 0
N[mask2]  = FaT
N[mask3a] = FaT
N[mask3b] = FaT - R3x
N[mask4]  = FaT - R3x



# Efforts tranchants
Ty = np.zeros_like(xx)
Ty[mask0]  = 0.0
Ty[mask1]  = R1y_v
Ty[mask2]  = R1y_v + FrT
Ty[mask3a] = R1y_v + FrT + R2y_v
Ty[mask3b] = R1y_v + FrT + R2y_v
Ty[mask4]  = R1y_v + FrT + R2y_v + R3y_v

Tz = np.zeros_like(xx)
Tz[mask0]  = 0.0
Tz[mask1]  = R1z_v
Tz[mask2]  = R1z_v - FtT
Tz[mask3a] = R1z_v - FtT + R2z_v
Tz[mask3b] = R1z_v - FtT + R2z_v
Tz[mask4]  = R1z_v - FtT + R2z_v + R3z_v

# Moments fléchissants (N·mm)
Mfz = np.zeros_like(xx)
Mfz[mask0]  = 0.0
Mfz[mask1]  = R1y_v*(xx[mask1] - x0)
Mfz[mask2]  = R1y_v*(xx[mask2] - x0)  + FrT*(xx[mask2] - x1)  + FaT*(dp_T/2.0)
Mfz[mask3a] = R1y_v*(xx[mask3a] - x0) + FrT*(xx[mask3a] - x1) + FaT*(dp_T/2.0)  + R2y_v*(xx[mask3a] - x2)
Mfz[mask3b] = R1y_v*(xx[mask3b] - x0) + FrT*(xx[mask3b] - x1) + FaT*(dp_T/2.0)  + R2y_v*(xx[mask3b] - x2)
Mfz[mask4]  = R1y_v*(xx[mask4] - x0)  + FrT*(xx[mask4] - x1)  + FaT*(dp_T/2.0)  + R2y_v*(xx[mask4] - x2) + R3y_v*(xx[mask4] - x3)

Mfy = np.zeros_like(xx)
Mfy[mask0]  = 0.0
Mfy[mask1]  = R1z_v*(xx[mask1] - x0)
Mfy[mask2]  = R1z_v*(xx[mask2] - x0) - FtT*(xx[mask2] - x1)
Mfy[mask3a] = R1z_v*(xx[mask3a] - x0) - FtT*(xx[mask3a] - x1) + R2z_v*(xx[mask3a] - x2)
Mfy[mask3b] = R1z_v*(xx[mask3b] - x0) - FtT*(xx[mask3b] - x1) + R2z_v*(xx[mask3b] - x2)
Mfy[mask4]  = R1z_v*(xx[mask4] - x0)  - FtT*(xx[mask4] - x1)  + R2z_v*(xx[mask4] - x2) + R3z_v*(xx[mask4] - x3)

Mf = np.sqrt(Mfz**2 + Mfy**2)

# Torsion
CT_Nmm = FtT*(dp_T/2.0)
Mt = np.zeros_like(xx)
Mt[mask0] = 0.0
Mt[mask1] = 0.0
Mt[mask2] = CT_Nmm
Mt[mask3a] = CT_Nmm
Mt[mask3b] = CT_Nmm
Mt[mask4] = CT_Nmm

Mi = np.sqrt(Mf**2 + Mt**2)

# Plots

plotT(xx, N,  r"Arbre T — Effort Normal $N(x)$", r"$N$ [N]")
plotT(xx, Ty,  r"Arbre T — Effort tranchant $T_y(x)$", r"$T_y$ [N]")
plotT(xx, Tz,  r"Arbre T — Effort tranchant $T_z(x)$", r"$T_z$ [N]")
plotT(xx, Mfy, r"Arbre T — Moment fléchissant $M_y(x)$", r"$M_y$ [Nm]")
plotT(xx, -Mfz, r"Arbre T — Moment fléchissant $M_z(x)$", r"$M_z$ [Nm]")
plotT(xx, Mf,  r"Arbre T — Moment résultant $M_f(x)$", r"$M_f$ [Nm]")
plotT(xx, Mt,  r"Arbre T — Torsion $M_t(x)$", r"$M_t$ [Nm]")
plotT(xx, Mi,  r"Arbre T — Moment idéal $M_i(x)$", r"$M_i$ [Nm]")




#Verif print
# 
#print("\n=== Castigliano OK ===")
#print(f"R1y = {R1y_v:.3f} N")
#print(f"R1z = {R1z_v:.3f} N")
#print(f"R2y = {R2y_v:.3f} N")
#print(f"R2z = {R2z_v:.3f} N")
#print(f"R3x = {R3x:.3f} N")
#print(f"R3y = {R3y_v:.3f} N")
#print(f"R3z = {R3z_v:.3f} N")
#
#
#
#
#print("\n--- Fermeture tranchants (x = L-) ---")
#print(f"Ty(L-) = {Ty[-1]:.2f} N ; attendu = {-mg:.2f} N ; diff = {Ty[-1] - mg:.2e}")
#print(f"Tz(L-) = {Tz[-1]:.2f} N ; attendu = {0} N ; diff = {Tz[-1] + 0:.2e}")
#
#
#print("\n--- Check fermeture moments ---")
#print(f"M_y(L-) = {Mfy[-1]:.2f} Nmm")
#print(f"M_z(L-) = {Mfz[-1]:.2f} Nmm")
#
#
#print("\n--- Check couple ---")
#print(f"Couple transmis = Ft * (dp_T / 2) = {CT_Nmm/1000:.2f} Nm")
#
#w2 = Nt * 2 * np.pi / 60
#print(f"P / wt = {P*1000 / w2:.2f} Nm")
#print(L_T)