from partie1_1 import *
import numpy as np

L1I_m = L1_I/1000  # m
L2I_m = L2_I/1000  # m
L3I_m = L3_I/1000  # m


LI_m = L1I_m+ L2I_m + L3I_m   # longueur totale entre paliers


a1 = L1I_m
b1 = L2I_m + L3I_m

a2 = L1I_m+ L2I_m
b2 = L3I_m



dI_m = d1[index] * 1e-3
I_I = np.pi * (dI_m)**4 / 64.0   # m^4




M1 = m_pinion_1[index]
M2 = m_wheel_1[index] 

# -----------------------
# 1) Contribution roue 
# -----------------------
a_ii_1 = (a1**2 * b1**2) / (3.0 * E * I_I * LI_m)
w_1 = np.sqrt(1.0 / (M1 * a_ii_1))

# -----------------------
# 2) Contribution pignon 
# -----------------------
a_ii_2 = (a2**2 * b2**2) / (3.0 * E * I_I * LI_m)
w_2 = np.sqrt(1.0 / (M2 * a_ii_2))



A_I = np.pi * dI_m**2 / 4.0
m_lin_I = rho * A_I   # kg/m

w_A = (np.pi**2 / LI_m**2) * np.sqrt(E * I_I / m_lin_I)


w_c = 1.0 / np.sqrt( 1.0 / w_1**2 + 1.0 / w_2**2 + 1.0 / w_A**2) 



N_rot = N1[index]
w_rot = 2.0 * np.pi * N_rot / 60.0
N_crit = w_c * 60.0 / (2.0 * np.pi)




#print("===== Verification dynamique arbre I =====")
#print(f"a_ii roue 1   = {a_ii_1:.6e} m/N")
#print(f"a_ii pignon 2 = {a_ii_2:.6e} m/N")
#print("\n")
#print(f"w_1   = {w_1:.3f} rad/s")
#print(f"w_2   = {w_2:.3f} rad/s")
#print(f"w_A   = {w_A:.3f} rad/s")
#print(f"w_c   = {w_c:.3f} rad/s")
#print(f"w_rot = {w_rot:.3f} rad/s")
#print("\n")
#print(f"N_crit = {N_crit:.1f} tr/min")
#print(f"N_rot  = {N_rot:.1f} tr/min")
#
#