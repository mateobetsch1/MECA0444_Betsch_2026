from partie1_1 import * 
from MNT_I import *

R = 900 / (3 * 1.8)

Mi = np.sqrt(Mf**2 + 3/4 * M_t**2)

Dser_I = ((32 * Mi) / (np.pi * R))**(1/3)


fig, ax = plt.subplots(figsize=(8, 5))

ax.plot(x,  Dser_I/2, 'r--', label=r"$D_{SER}^I(x)$")
ax.plot(x, -Dser_I/2, 'r--')

ax.plot(x,  d1[index]/2 * np.ones_like(x), 'b-', linewidth=2, label=r"$d^I$ réel")
ax.plot(x, -d1[index]/2 * np.ones_like(x), 'b-')

ax.fill_between(x, -Dser_I/2, Dser_I/2, color="red", alpha=0.1)
ax.fill_between(x, -Dser_I/2, -d1[index]/2, color="green", alpha=0.1)
ax.fill_between(x, +Dser_I/2, +d1[index]/2, color="green", alpha=0.1)


ax.set_xlabel("x [mm]")
ax.set_ylabel("Diamètre [mm]")
ax.set_title("Arbre I — D_SER variable")
ax.grid(True)
ax.legend()

os.makedirs("figures_I", exist_ok=True)
fig.savefig("figures_I/DSER_I.png", dpi=600)
plt.close(fig)

# =========================
# Verification cisaillement
# =========================

#Cisaillement résultant
T = np.sqrt(Ty**2 + Tz**2)


term1 = 16*np.abs(M_t)/(np.pi*d1[index]**3)
term2 = 16*np.abs(T)/(3*np.pi*d1[index]**2)
tau =  term1 + term2

i = np.argmax(tau)

tau_max = tau[i]



tau_lim = R/2

    
fig, ax = plt.subplots(figsize=(8,5))

ax.plot(x, term1, linewidth=2, label=r"$\tau_{M_t}$")
ax.plot(x, term2, '--', linewidth=2, label=r"$\tau_T$")

ax.set_xlabel("x [mm]")
ax.set_ylabel(r"$\tau$ [MPa]")
ax.set_title("Arbre I — contraintes de cisaillement")

ax.set_ylim(0, 12)

# grille plus légère
ax.grid(True, linestyle="--", alpha=0.6)

ax.legend(loc="upper right")

# annotation contrainte admissible
ax.text(
    0.02, 0.95,
    r"$\tau_{adm}=83.3\ \mathrm{MPa}$",
    transform=ax.transAxes,
    fontsize=12,
    verticalalignment='top',
    bbox=dict(facecolor='white', edgecolor='red', boxstyle="round")
)

fig.tight_layout()
os.makedirs("figures_I", exist_ok=True)
fig.savefig("figures_I/tau_verif_I.png", dpi=600)

plt.close(fig)



#print(f"Dser max = {np.max(Dser_I):.2f} mm")
#print(f"d_I = {d1[index]:.2f} mm")
#
#opti = (d1[index]/np.max(Dser_I))**2
#print(f"Facteur de surdimenssionement : {opti:.2f}")
#
#print("\n--- Verification cisaillement arbre I ---")
#print(f"tau_max = {tau_max:.2f} MPa")
#print(f"tau_lim = {tau_lim:.2f} MPa")
#print(f"tau_max_Mt = {term1[i]:.2f} Mpa")
#print(f"tau_max_T = {term2[i]:.2f} Mpa")
#
#
#if tau_max < tau_lim:
#    print("OK : critere de cisaillement respecte")
#else:
#    print("NON : arbre insuffisant")