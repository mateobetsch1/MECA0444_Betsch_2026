import numpy as np
import matplotlib.pyplot as plt

# ===============================#
#           Template             #
# ===============================#
plt.rcParams.update({
    'font.size': 15,
    'lines.linewidth': 2
})
grid_style = {'linestyle': '--', 'linewidth': 1.2, 'alpha': 0.8, 'which': 'both'}

# ===============================#
#           Données              #
# ===============================#
p = 7
P = 200 + p * 10               # kW
M = 100 + p * 5                # kg
m = 10                         # kg
Nt = 22000                     # tr/min
Lg = 500                       # mm
E = 210e9  # Pa
Lf = 12000                     # h
Tmaintenance = 3000            # h
C2 = 1000                      # Nm
Ct = P * 1e3 * 60 / (Nt * 2 * np.pi)   # Nm
r_moyen = 107                          # mm
F1 = Ct / (r_moyen * 1e-3)             # N
F2 = F1 * np.tan(np.radians(30))       # N
F_a_max = 2 * F2                       # N
g = 9.81    #m/s^2
rho = 7900  # kg/m^3



#=========================#
#    Arbre T dimmenssion  #
#=========================#

L0T = 50.0 #mm
L1T = 62.5  #mm 
L2T = 500.0 #mm
L3T = 50.0  #mm

L_T =L0T + 2*L1T +L2T +L3T 

#=========================#
#    Arbre I dimmenssion  #
#=========================#

L1_I, L2_I, L3_I = 45, 45, 45  # [mm]
L_I = L1_I + L2_I + L3_I

#=========================#
#    Arbre II dimmenssion #
#=========================#

L1_II, L2_II, L3_II = 90, 90, 20  # [mm]
L_II = L1_II + L2_II + L3_II




# ===============================#
#   Fonctions utiles             #
# ===============================#

def diametre_manege(P_kw, N_tr_min):
    """
    Formule "arbres de manège" 
    P en kW, N en tr/min, retourne d en mm.
    Formule valide pour P/N < 1 (ici on a P ~ 100 kw et N ~ 5000-20000 tr/min donc ok) 
    """

    return 130.0 * (P_kw / N_tr_min) ** (1.0 / 4.0)

def masse_cylindre_plein(L_mm, D_mm):
    """
    Masse d'un cylindre plein (acier), L et D en mm -> kg
    """
    L = L_mm * 1e-3
    D = D_mm * 1e-3
    return rho * np.pi * (D**2) * L / 4.0

def masse_cylindre_creux(L_mm, Dext_mm, Dint_mm):
    """
    Masse d'un cylindre creux (acier), L et D en mm -> kg
    """
    L = L_mm * 1e-3
    Dext = Dext_mm * 1e-3
    Dint = Dint_mm * 1e-3
    return rho * np.pi * L * (Dext**2 - Dint**2) / 4.0

def force_engrenage(P, d, N, alpha_deg, beta_deg):  
    """
    Force de contact dans un engrenage helicoidale, P en kW, d en mm, N en tr/min, alpha et beta en degrés. 
    Retourne F_t, F_r, F_a en N.
    """
    P_W = P * 1e3  # kW -> W
    d_m = d * 1e-3  # mm -> m
    w = N * 2 * np.pi / 60  
    alpha_rad = np.radians(alpha_deg)
    beta_rad = np.radians(beta_deg)
    Q = P_W / (w * d_m / 2)  
    F_t = Q 
    F_r = Q * np.tan(alpha_rad) / np.cos(beta_rad)
    F_a = Q * np.tan(beta_rad)
    return F_t, F_r, F_a

# ===============================#
#   Paramétrisation (R, R1)      #
# ===============================#

R = 4.8
R_vals  = np.linspace(R * (1 - 0.015), R * (1 + 0.015), 60)
R1_vals = np.linspace(1.2, 4.0, 120)

RR1, RR = np.meshgrid(R1_vals, R_vals)   # RR1: colonnes=R1, RR: lignes=R si on ne fait pas ceci on ne sais pas représenter sur une heat map
R2 = RR / RR1

N1 = Nt / RR1
N2 = Nt / RR

# ===============================#
#   Diamètres arbres (manège)    #
# ===============================#

dt = diametre_manege(P, Nt)    # mm (scalaire)
d1 = diametre_manege(P, N1)    # mm (matrice)
d2 = diametre_manege(P, N2)    # mm (matrice)

# ===============================#
#   Diamètres Roues et pignons   #
# ===============================#
# Énoncé: pignons d >= 1.8 * d_arbre (via la formule des manèges) 

k_pignon = 1.85 

# Étage 1:
d_pinion_T = k_pignon * dt          # pignon sur l'arbre turbine (mm) (scalaire)
d_wheel_1  = RR1 * d_pinion_T       # roue correspondante sur l'arbre 1 (mm) (matrice)

# Étage 2:
d_pinion_1 = k_pignon * d1          # pignon sur l'arbre 1 (mm) (matrice)
d_wheel_2  = R2 * d_pinion_1        # roue sur l'arbre 2 (mm) (matrice)





#Largeurs de pignons et roues (mm)
b1 = 30.0  # mm
b2 = 30.0  # mm


mT = masse_cylindre_plein(L_T, dt)     # kg (scalaire)
m1 = masse_cylindre_plein(L_I, d1)     # kg (matrice)
m2 = masse_cylindre_plein(L_II, d2)     # kg (matrice)



m_pinion_T = masse_cylindre_creux(b1, d_pinion_T, dt)   # kg (scalaire)
m_wheel_1  = masse_cylindre_creux(b1, d_wheel_1,  d1)   # kg (matrice)
m_pinion_1 = masse_cylindre_creux(b2, d_pinion_1, d1)   # kg (matrice)
m_wheel_2  = masse_cylindre_creux(b2, d_wheel_2,  d2)   # kg (matrice)

m_tot = mT + m1 + m2 + m_pinion_T + m_wheel_1 + m_pinion_1 + m_wheel_2

# ===============================#
#   Plot heatmap                 #
# ===============================#
plt.figure()
im = plt.imshow(
    m_tot,
    origin="lower",
    aspect="auto",
    extent=[R1_vals.min(), R1_vals.max(), R_vals.min(), R_vals.max()]
)
plt.colorbar(im, label="Masse totale [kg]")
plt.xlabel("R1 [-]" )
plt.ylabel("R [-]")
#plt.show()                                                                             # enlevé ici pour voir m_tot = f(R, R1)

m_min = np.min(m_tot)
index = np.unravel_index(np.argmin(m_tot), m_tot.shape)







# ===============================#
#       Print                    #
# ===============================#




#print(f"Masse optimale : {m_min:.2f} kg".format(float))
#print("\n")
#
#print(f"R1 optimal : {RR1[index]:.3f}".format(float))
#print(f"R2 optimal : {R2[index]:.3f}".format(float))
#print(f"R optimal : {RR[index]:.3f}".format(float))  #===> Retourne la valeur de R la plus petite
#print("\n")
#
#print(f"N1 optimal : {N1[index]:.2f} tr/min".format(float))
#print(f"N2 optimal : {N2[index]:.2f} tr/min".format(float))
#print(f"Nt fixe : {Nt:.2f} tr/min".format(float))
#print("\n")
#
#
#print(f"Diametre arbre 1 optimal : {d1[index]:.2f} mm".format(float))
#print(f"Diametre arbre 2 optimal : {d2[index]:.2f} mm".format(float))
#print(f"Diametre arbre t (fixe) : {dt:.2f} mm".format(float))
#print("\n")
#
#
#print(f"Diametre pignon 1 optimal : {d_pinion_1[index]:.2f} mm".format(float))
#print(f"Diametre pignon t (fixe) : {d_pinion_T:.2f} mm".format(float))
#print(f"Diametre roue 1 optimal : {d_wheel_1[index]:.2f} mm".format(float))
#print(f"Diametre roue 2 optimal : {d_wheel_2[index]:.2f} mm".format(float))
#print("\n")
