import os
import matplotlib.pyplot as plt
import numpy as np
from MNT_T import *


R = 900 / (3 * 1.8)  # MPa = N/mm^2

Mf_max = np.max(Mf)          # Nmm
Mt_dser = CT_Nmm             # Nmm
Mi_max = np.sqrt(Mf_max**2 + 3/4* Mt_dser**2)

D_T = ((32 * Mi_max) / (np.pi * R))**(1/3)


fig, ax = plt.subplots(figsize=(8, 5))

ax.plot(xx, np.zeros_like(xx), color='black', linewidth=1, linestyle="--")

ax.plot(xx,  D_T*np.ones_like(xx)/2, color='red', linewidth=1, linestyle="--", label=r"$D_{SER}^T$")
ax.plot(xx, -D_T*np.ones_like(xx)/2, color='red', linewidth=1, linestyle="--")

ax.plot(xx,  dt*np.ones_like(xx)/2, color='blue', linewidth=1.5, linestyle="-", label=r"$d_T$ réel")
ax.plot(xx, -dt*np.ones_like(xx)/2, color='blue', linewidth=1.5, linestyle="-")

ax.fill_between(xx, -D_T/2, D_T/2, color="red", alpha=0.1)
ax.fill_between(xx, -D_T/2, -dt/2, color="green", alpha=0.1)
ax.fill_between(xx, D_T/2, dt/2, color="green", alpha=0.1)



y_ticks = np.arange(-30, 31, 10)

ax.set_yticks(y_ticks)

ax.grid(True, linestyle="--", alpha=0.2)  


ax.set_xlabel("x [mm]")
ax.set_ylabel("Diamètre [mm]")
ax.set_title("Arbre T — Comparaison diamètre réel / $D_{SER}$")
ax.legend(loc = "center")

fig.tight_layout()

os.makedirs("figures_T", exist_ok=True)
filepath = os.path.join("figures_T", "DSER_T.png")
fig.savefig(filepath, dpi=600)
plt.close(fig)


T = np.sqrt(Ty**2 + Tz**2)


term1 = 16*np.abs(Mt)/(np.pi*dt**3)
term2 = 16*np.abs(T)/(3*np.pi*dt**2)
tau =  term1 + term2



i = np.argmax(tau)
tau_max = float(tau[i])

tau_lim = R/2

#print("\n--- Verification cisaillement arbre T ---")
#print(f"tau_max = {tau_max:.2f} MPa")
#print(f"tau_lim = {tau_lim:.2f} MPa")
#print(f"tau_max_Mt = {term1[i]:.2f} Mpa")
#print(f"tau_max_T = {term2[i]:.2f} Mpa")
#
#if tau_max < tau_lim:
#    print("OK : critere de cisaillement respecte")
#else:
#    print("NON : arbre insuffisant")
#
#print("\n--- Dimensionnement arbre T ---")
#print(f"Moment flechissant max Mf = {Mf_max:.2f} Nmm")
#print(f"Moment de torsion = {Mt_dser:.2f} Nmm")
#print(f"Moment ideal max Mi = {Mi_max:.2f} Nmm")
#print(f"Diametre de securite D_T = {D_T:.2f} mm")
#print(f"Diametre de reel d_T = {dt:.2f} mm")
#volume_surplu = (dt/ D_T)**2
#print(fr"D_T^2 / dt^2 ={volume_surplu:.2f}")