import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
import os
from partie1_1 import *  
from opti_angle import *



# Discrétisation
x = np.linspace(0, L_I, 2000)
x1 = L1_I
x2 = L1_I + L2_I


TOL = 1e-6

# =========================
# Fonction de plot des diag (pas de répétitions)
# =========================
def plot1(y, title, ylabel):
    os.makedirs("figures_I", exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(x, y, linewidth=2)

    ax.axvline(x1, linestyle="--", color="orange", linewidth=1.5)
    ax.axvline(x2, linestyle="--", color="orange", linewidth=1.5)

    ax.grid(True, linestyle="--", alpha=0.7)

    ax.set_xlabel("x [mm]", fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=13)

    ax.set_xlim(0, L_I)
    ax.set_xticks(np.arange(0, L_I + 1, 25))

    fig.tight_layout()
    plt.grid(True, **grid_style)
    filepath = os.path.join("figures_I", title + ".png")
    fig.savefig(filepath, dpi=600)
    plt.close(fig)


Ft_P1, Fr_P1, Fa_P1 = force_engrenage(P, dp_1, N1[index], 20, best_beta2)

#Non signée 
Ft1 = float(Ft_P1)
Fr1 = float(Fr_P1)
Fa1 = float(Fa_P1)


Ft2  =float(Ft_R1) 
Fr2 = float(Fr_R1)
Fa2 = float(Fa_R1)



# =========================
# IMPORTANT : forces SIGNÉES selon la convention choisie
# =========================

# Direction y (radial) :
theta = np.radians(60)
Fy1 = +Fr1*np.cos(theta) + Ft1 * np.sin(theta) 
Fy2 = -Fr2   

# Direction z (tangentielle) :
Fz1 = -Fr1 * np.sin(theta) + Ft1 * np.cos(theta)   
Fz2 = Ft2   

# Direction x (axial) :
Fx1 = -Fa1    
Fx2 = +Fa2  

# =========================
# Réactions d'appuis (sympy) — forces SIGNÉES => plus simple pour les MNT 
# =========================
R1x, R1y, R2y, R1z, R2z = sp.symbols("R1x R1y R2y R1z R2z")

eqs = []

# Sommes des forces = 0
eqs.append(sp.Eq(R1x + Fx1 + Fx2, 0))
eqs.append(sp.Eq(R1y + R2y + Fy1 + Fy2, 0))
eqs.append(sp.Eq(R1z + R2z + Fz1 + Fz2, 0))

# Moments en x=0 :
eqs.append(sp.Eq(R2y * L_I + Fy1 * x1 + Fy2 * x2 - Fa1 * (dp_1/2.0) - Fa2 * (dr_1/2.0),0))    #autour de z 
eqs.append(sp.Eq(R2z * L_I + Fz1 * x1 + Fz2 * x2,0))                                            #autour de y



sol = sp.solve(eqs, [R1x, R1y, R2y, R1z, R2z], dict=True)
if not sol:
    raise RuntimeError("Pas de solution pour les réactions de l'arbre I.")
sol = sol[0]

R1x_v = float(sol[R1x])
R1y_v = float(sol[R1y])
R2y_v = float(sol[R2y])
R1z_v = float(sol[R1z])
R2z_v = float(sol[R2z])


# =========================
# Vérification équilibre global 
# =========================
sumFx = R1x_v + Fx1 + Fx2
sumFy = R1y_v + R2y_v + Fy1 + Fy2
sumFz = R1z_v + R2z_v + Fz1 + Fz2



mask1 = (x >= 0) & (x < x1)
mask2 = (x >= x1) & (x < x2)
mask3 = (x >= x2) & (x <= L_I)
# N(x)
N = np.zeros_like(x)
N[mask1] = -R1x_v
N[mask2] = -R1x_v + Fa1
N[mask3] = -R1x_v + Fa1 - Fa2

# Ty(x)
Ty = np.zeros_like(x)
Ty[mask1] = R1y_v
Ty[mask2] = R1y_v + Fy1
Ty[mask3] = R1y_v + Fy1 + Fy2

# Tz(x)
Tz = np.zeros_like(x)
Tz[mask1] = R1z_v
Tz[mask2] = R1z_v + Fz1
Tz[mask3] = R1z_v + Fz1 + Fz2

# Moments (N·mm) : moments des forces à gauche de la section
My = np.zeros_like(x)  # autour de y (forces en z)
Mz = np.zeros_like(x)  # autour de z (forces en y)



M0_1 = Fa1 * (dp_1 / 2.0)   # couple appliqué selon z  en x1 (N·mm)
M0_2 = Fa2 * (dr_1 / 2.0)   # couple appliqué selon z  en x2 (N·mm)

My[mask1] = -R1z_v * x[mask1]
My[mask2] = -R1z_v * x[mask2] - Fz1 * (x[mask2] - x1)
My[mask3] = -R1z_v * x[mask3] - Fz1 * (x[mask3] - x1) - Fz2 * (x[mask3] - x2)

Mz[mask1] = R1y_v * x[mask1]
Mz[mask2] = R1y_v * x[mask2] + Fy1 * (x[mask2] - x1) + M0_1
Mz[mask3] = R1y_v * x[mask3] + Fy1 * (x[mask3] - x1) + Fy2 * (x[mask3] - x2) + M0_1 + M0_2

Mf = np.sqrt(My**2 + Mz**2)



if (abs(Ft_P1*(dp_1/2) - Ft_R1*(dr_1/2)) < TOL): 
    M_t = np.zeros_like(x)
    M_t[mask2] = Ft_P1*(dp_1/2)
else:
    raise RuntimeError("ATTENTION : Couple de torsion incohérent entre pignon 1 et roue 1 (vérifier les forces Ft et les diamètres dp_1/dr_1).")



# =========================
# Plots
# =========================
plot1(N,  r"Arbre I — Effort normal $N(x)$", r"$N$ [N]")
plot1(Ty, r"Arbre I — Effort tranchant $T_y(x)$", r"$T_y$ [N]")
plot1(Tz, r"Arbre I — Effort tranchant $T_z(x)$", r"$T_z$ [N]")
plot1(My, r"Arbre I — Moment fléchissant $M_y(x)$", r"$M_y$ [N·mm]")
plot1(Mz, r"Arbre I — Moment fléchissant $M_z(x)$", r"$M_z$ [N·mm]")
plot1(Mf, r"Arbre I — Moment résultant $M_f(x)$", r"$M_f$ [N·mm]")
Mi = np.sqrt(Mf**2 + M_t**2)

plot1(M_t, r"Arbre I — Torsion $M_t(x)$", r"$M_t$ [N·mm]")
plot1(Mi, r"Arbre I — Moment idéal $M_i(x)$", r"$M_i$ [N·mm]")




#Vérif print 

#
#print("\n=== Reactions Arbre I  ===")
#print(f"R1x = {R1x_v:.2f} N")
#print(f"R1y = {R1y_v:.2f} N, R2y = {R2y_v:.2f} N")
#print(f"R1z = {R1z_v:.2f} N, R2z = {R2z_v:.2f} N")
#
#print("\n--- Check equilibre global Arbre I ---")
#print(f"SumFx = {sumFx:.6e}")
#print(f"SumFy = {sumFy:.6e}")
#print(f"SumFz = {sumFz:.6e}")
#
#if max(abs(sumFx), abs(sumFy), abs(sumFz)) > TOL:
#    print("ATTENTION : equilibre global NON respecté (signe(s) à corriger dans Fy/Fz/Fx).")
#else:
#    print("Equilibre global OK.")
#
## =========================
## Vérification fermeture tranchants à droite
## =========================
#print("\n--- Fermeture tranchants (x = L-) ---")
#print(f"Ty(L-) = {Ty[-1]:.2f}  ;  -R2y = {-R2y_v:.2f}  ;  diff = {Ty[-1] + R2y_v:.2e}")
#print(f"Tz(L-) = {Tz[-1]:.2f}  ;  -R2z = {-R2z_v:.2f}  ;  diff = {Tz[-1] + R2z_v:.2e}")
#
#print("\n--- CHECK COUPLE ARBRE I ---")
#print(f"Ft_P1 = {Ft_P1:.2f} N ; dp_1 = {dp_1:.2f} mm  -> CT = {Ft_P1*(dp_1/2):.2f} Nmm")
#print(f"Ft_R1 = {Ft_R1:.2f} N ; dr_1 = {dr_1:.2f} mm  -> CT = {Ft_R1*(dr_1/2):.2f} Nmm")
#omega1 = 2*np.pi * N1[index] / 60          # rad/s
#CT_from_P = (P*1e3) / omega1                # N·m
#CT_from_P_Nmm = CT_from_P * 1e3              # N·mm
#print(f"CT = P/w1 = {CT_from_P_Nmm:.2f} Nmm")